/*H***************************************************************************
*
* $Archive:: /xds100/FTDI/ina_j5eco/ina_j5eco.cpp                            $
* $Revision:: 8                                                              $
* $Date:: 7/22/13 9:12a                                                      $
* $Author:: Tonyc                                                            $
*
* HISTORY:
*
* DESCRIPTION: This is really simple I2C app that scans through the INA226
*              devices on an SD J5ECO or Vayu board.
*
* GLOBALS
*
* PUBLIC FUNCTIONS:
*
* PRIVATE FUNCTIONS:
*
* USAGE/LIMITATIONS: Tested on FTDI FT2232H_mini_module with the following
*                    connections:
*                    CN2 pin 1 to pin 11, connects 3.3V to VIO
*                    CN3 pin 1 to pin 3, connects VBUS to VCC
*                    CN3 pin 24 to pin 25, connects BD1 to BD2, SDA
*                    
*                    J5ECO J18 mapping to FT2232H_mini_module
*                       J18 pin 1 to CN3 pin 26 SCL  violate
*                       J18 pin 2 to CN3 pin 24 SDA  brown
*                       J18 pin 3 to CN3 pin 2 GND   grey
*
*                   Tested on 517300 "FTDI I2C Controller" and Vayu CPU
*                   board.
*
*
* NOTES:
*
* Copyright (C) 2003-2012 by Spectrum Digital Incorporated
* All rights reserved
* Released under the terms of the BSD-style license terms shown below.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*	- Redistributions of source code must retain the above copyright
*	  notice, this list of conditions and the following disclaimer.
*	- Redistributions in binary form must reproduce the above copyright
*	  notice, this list of conditions and the following disclaimer in the
*	  documentation and/or other materials provided with the distribution.
*	- Neither the name of the <organization> nor the
*	  names of its contributors may be used to endorse or promote products
*	  derived from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
*H***************************************************************************/

#include "stdafx.h"
#include <windows.h>

#pragma warning(disable:4996)

//============================================================================
//  Use of FTDI D2XX library:
//----------------------------------------------------------------------------
//  Include the following 2 lines in your header-file
#pragma comment(lib, "FTD2XX.lib")
#include "FTD2XX.h"
//============================================================================

#include <stdlib.h>

    const DWORD MSG_ALL                 = 9;
    const DWORD MSG_DEBUG               = 8;
    const DWORD MSG_MEASURE             = 7;
    const DWORD MSG_RANGE               = 6;

    const DWORD CHANNEL_TO_OPEN			= 1;	
    const DWORD PID_XDS100V2            = 0x0403a6d0;
    const DWORD PID_XDS100V3            = 0x0403a6d1;

    const int  I2C_NUM_MONITORS         = 12;

#if defined( VAYU_CPU ) || defined( DM8148_CPU )
    const BYTE I2C_ADDR_VDD_DSPEVE           = 0x40;
    const BYTE I2C_ADDR_VDD_MPU              = 0x41;
    const BYTE I2C_ADDR_DDR_CPU              = 0x42;
    const BYTE I2C_ADDR_VDDA_1V8_PLL         = 0x43;
    const BYTE I2C_ADDR_VDD_GPU              = 0x44;
    const BYTE I2C_ADDR_VUSB_3V3             = 0x45;
    const BYTE I2C_ADDR_VDDS18V              = 0x46;
    const BYTE I2C_ADDR_VDD_SHV              = 0x47;
    const BYTE I2C_ADDR_CORE_VDD             = 0x48;
    const BYTE I2C_ADDR_VDD_IVA              = 0x49;
    const BYTE I2C_ADDR_DDR_MEM              = 0x4A;
    const BYTE I2C_ADDR_VDDA_1V8_PHY         = 0x4B;
#else
    const BYTE I2C_ADDR_U73              = 0x40;
    const BYTE I2C_ADDR_U75              = 0x41;
    const BYTE I2C_ADDR_U78              = 0x42;
    const BYTE I2C_ADDR_U80              = 0x43;
    const BYTE I2C_ADDR_U74              = 0x44;
    const BYTE I2C_ADDR_U81              = 0x45;
    const BYTE I2C_ADDR_U82              = 0x46;
    const BYTE I2C_ADDR_U83              = 0x47;
    const BYTE I2C_ADDR_U76              = 0x48;
    const BYTE I2C_ADDR_U77              = 0x49;
    const BYTE I2C_ADDR_U79              = 0x4A;
    const BYTE I2C_ADDR_U84              = 0x4B;
#endif

    const BYTE INA_REG_CONFIG           = 0;
    const BYTE INA_REG_SHUNT            = 1;
    const BYTE INA_REG_BUS              = 2;
    const BYTE INA_REG_POWER            = 3;
    const BYTE INA_REG_CURRENT          = 4;
    const BYTE INA_REG_CALIBRATION      = 5;
    const BYTE INA_REG_MASK_ENABLE      = 6;
    const BYTE INA_REG_ALERT_LIMIT      = 7;
    const BYTE INA_REG_DIE_ID           = 255;

    const USHORT INA_CONFIG_VAL         = 0x4127;  // INA226

	const BYTE AA_ECHO_CMD_1            = '\xAA';
	const BYTE AB_ECHO_CMD_2            = '\xAB';
	const BYTE BAD_COMMAND_RESPONSE     = '\xFA';

	const BYTE MSB_VEDGE_CLOCK_IN_BIT   = '\x22';
	const BYTE MSB_EDGE_CLOCK_OUT_BYTE  = '\x11';
	const BYTE MSB_EDGE_CLOCK_IN_BYTE   = '\x24';

	const BYTE MSB_FALLING_EDGE_CLOCK_BYTE_IN   = '\x24';
	const BYTE MSB_FALLING_EDGE_CLOCK_BYTE_OUT  = '\x11';
	const BYTE MSB_DOWN_EDGE_CLOCK_BIT_IN       = '\x26';
	const BYTE MSB_UP_EDGE_CLOCK_BYTE_IN        = '\x20';
	const BYTE MSB_UP_EDGE_CLOCK_BYTE_OUT       = '\x10';
	const BYTE MSB_RISING_EDGE_CLOCK_BIT_IN     = '\x22';
    
    const double  SHUNT_UV_PER_LSB =  2.50;   // +-80mv, 2.5uV per LSB
    const double  BUS_MV_PER_LSB   =  1.25;   // 1.25mV per LSB;


	FT_STATUS ftStatus;			//Status defined in D2XX to indicate operation result
	FT_HANDLE ftHandle;			//Handle of FT2232H device port 
	BYTE OutputBuffer[1024];		//Buffer to hold MPSSE commands and data to be sent to FT2232H
	BYTE InputBuffer[1024];		//Buffer to hold Data bytes to be read from FT2232H
	//DWORD dwClockDivisor = 0x004A;  	//Value of clock divisor, SCL Frequency = 60/((1+0x004A)*2) (MHz) = 400khz
	DWORD dwClockDivisor    = 0x0095;   //200khz
	DWORD dwNumBytesToSend  = 0; 	//Index of output buffer
	DWORD dwNumBytesSent    = 0;
    DWORD dwNumBytesRead    = 0;
    DWORD dwNumInputBuffer  = 0;

    DWORD  Verbose           = MSG_ALL;

    DWORD ConfigPort       = CHANNEL_TO_OPEN;
    DWORD ConfigVal        = INA_CONFIG_VAL;
    DWORD ConfigDelay      = 0;
    DWORD ConfigMask       = 0x0FFF;
    DWORD ConfigNumSamples = 100;

    typedef struct ina_dev 
    {
        BYTE          Address;
        BOOL          Present;
        const char *  Device;
        double        MonResistor;
        double        VbusExpectedMv;
        double        VbusDeltaMv;
        double        VbusSumMv;
        USHORT        regConfig;             // R/W 
        USHORT        regShunt;              // RO Signed
        USHORT        regBus;                // RO Unsigned, 3 LSB are status
        USHORT        regPower;              // RO Unsigned
        USHORT        regCurrent;            // RO Signed
        USHORT        regCalibration;        // R/W
    } INA_DEV;

    INA_DEV DevList[I2C_NUM_MONITORS];

void HighSpeedSetI2CStart(void)
{
	DWORD dwCount;
	for(dwCount=0; dwCount < 4; dwCount++)	// Repeat commands to ensure the minimum period of the start hold time ie 600ns is achieved
	{
		OutputBuffer[dwNumBytesToSend++] = '\x80';	//Command to set directions of lower 8 pins and force value on bits set as output
		OutputBuffer[dwNumBytesToSend++] = '\x03';  //Set SDA, SCL high, WP disabled by SK, DO at bit ��1��, GPIOL0 at bit ��0��
		OutputBuffer[dwNumBytesToSend++] = '\x13';	//Set SK,DO,GPIOL0 pins as output with bit ��1��, other pins as input with bit ��0��
	}
	for(dwCount=0; dwCount < 4; dwCount++)	// Repeat commands to ensure the minimum period of the start setup time ie 600ns is achieved
	{
		OutputBuffer[dwNumBytesToSend++] = '\x80'; 	//Command to set directions of lower 8 pins and force value on bits set as output
		OutputBuffer[dwNumBytesToSend++] = '\x01'; 	//Set SDA low, SCL high, WP disabled by SK at bit ��1��, DO, GPIOL0 at bit ��0��
		OutputBuffer[dwNumBytesToSend++] = '\x13';	//Set SK,DO,GPIOL0 pins as output with bit ��1��, other pins as input with bit ��0��
	}
	OutputBuffer[dwNumBytesToSend++] = '\x80'; 	//Command to set directions of lower 8 pins and force value on bits set as output
	OutputBuffer[dwNumBytesToSend++] = '\x00'; 	//Set SDA, SCL low high, WP disabled by SK, DO, GPIOL0 at bit ��0��
	OutputBuffer[dwNumBytesToSend++] = '\x13';	//Set SK,DO,GPIOL0 pins as output with bit ��1��, other pins as input with bit ��0��
}

void HighSpeedSetI2CStop(void)
{
	DWORD dwCount;
	for(dwCount=0; dwCount<4; dwCount++)	// Repeat commands to ensure the minimum period of the stop setup time ie 600ns is achieved
	{
		OutputBuffer[dwNumBytesToSend++] = '\x80'; 	//Command to set directions of lower 8 pins and force value on bits set as output
		OutputBuffer[dwNumBytesToSend++] = '\x01'; 	//Set SDA low, SCL high, WP disabled by SK at bit ��1��, DO, GPIOL0 at bit ��0��
		OutputBuffer[dwNumBytesToSend++] = '\x13';	//Set SK,DO,GPIOL0 pins as output with bit ��1��, other pins as input with bit ��0��
	}
	for(dwCount=0; dwCount<4; dwCount++)	// Repeat commands to ensure the minimum period of the stop hold time ie 600ns is achieved
	{
		OutputBuffer[dwNumBytesToSend++] = '\x80'; 	//Command to set directions of lower 8 pins and force value on bits set as output
		OutputBuffer[dwNumBytesToSend++] = '\x03'; 	//Set SDA, SCL high, WP disabled by SK, DO at bit ��1��, GPIOL0 at bit ��0��
		OutputBuffer[dwNumBytesToSend++] = '\x13';	//Set SK,DO,GPIOL0 pins as output with bit ��1��, other pins as input with bit ��0��
	}
	//Tristate the SCL, SDA pins
	OutputBuffer[dwNumBytesToSend++] = '\x80'; 	//Command to set directions of lower 8 pins and force value on bits set as output
	OutputBuffer[dwNumBytesToSend++] = '\x10'; 	//Set WP disabled by GPIOL0 at bit 0��
	OutputBuffer[dwNumBytesToSend++] = '\x10';	//Set GPIOL0 pins as output with bit ��1��, SK, DO and other pins as input with bit ��0��
}

BOOL SendByteAndCheckACK(BYTE dwDataSend)
{
	FT_STATUS ftStatus = FT_OK;
    BOOL success = TRUE;

	OutputBuffer[dwNumBytesToSend++] = MSB_FALLING_EDGE_CLOCK_BYTE_OUT; 	//clock data byte out on �Cve Clock Edge MSB first
	OutputBuffer[dwNumBytesToSend++] = '\x00';
	OutputBuffer[dwNumBytesToSend++] = '\x00';	//Data length of 0x0000 means 1 byte data to clock out
	OutputBuffer[dwNumBytesToSend++] = dwDataSend;	//Set control byte, bit 4-7 of ��1010�� as 24LC02 control code, bit 1-3 as block select bits  //which is don��t care here, bit 0 of ��0�� represent Write operation
	//Get Acknowledge bit from EEPROM
	OutputBuffer[dwNumBytesToSend++] = '\x80'; 	//Command to set directions of lower 8 pins and force value on bits set as output
	OutputBuffer[dwNumBytesToSend++] = '\x00'; 	//Set SCL low, WP disabled by SK, GPIOL0 at bit ��0��
	OutputBuffer[dwNumBytesToSend++] = '\x11';	//Set SK, GPIOL0 pins as output with bit ��1��, DO and other pins as input with bit ��0��
	OutputBuffer[dwNumBytesToSend++] = MSB_RISING_EDGE_CLOCK_BIT_IN; 	//Command to scan in acknowledge bit , -ve clock Edge MSB first
	OutputBuffer[dwNumBytesToSend++] = '\x0';	//Length of 0x0 means to scan in 1 bit

	OutputBuffer[dwNumBytesToSend++] = '\x87';	//Send answer back immediate command
	ftStatus = FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);		//Send off the commands
	dwNumBytesToSend = 0;			//Clear output buffer
	//Check if ACK bit received, may need to read more times to get ACK bit or fail if timeout
	ftStatus = FT_Read(ftHandle, InputBuffer, 1, &dwNumBytesRead);  	//Read one byte from device receive buffer
	if ((ftStatus != FT_OK) || (dwNumBytesRead == 0))
	{
		//printf("fail to get ACK when send control byte 1 [Program Section] \n");
			success = FALSE; //Error, can't get the ACK bit from EEPROM
	}
	else 
	{
		if (((InputBuffer[0] & BYTE('\x1'))  != BYTE('\x0'))	)	//Check ACK bit 0 on data byte read out
		{	
			//printf("fail to get ACK when send control byte 2 [Program Section] \n");
			success = FALSE; //Error, can't get the ACK bit from EEPROM
		}
	}
	
	OutputBuffer[dwNumBytesToSend++] = '\x80'; 	//Command to set directions of lower 8 pins and force value on bits set as output
	OutputBuffer[dwNumBytesToSend++] = '\x02'; 	//Set SDA high, SCL low, WP disabled by SK at bit '0', DO, GPIOL0 at bit '1'
	OutputBuffer[dwNumBytesToSend++] = '\x13';	//Set SK,DO,GPIOL0 pins as output with bit ��1��, other pins as input with bit ��0��
	return success;
}

BOOL 
inaPresent( BYTE Device )
{
    BYTE devRead     = (Device<<1) |  1;
    BOOL bSucceed    = FALSE;
    ftStatus         = FT_OTHER_ERROR;
    dwNumBytesToSend = 0;

    Sleep(100);

	//////////////////////////////////////////////////////////
	// Set I2C start condition
	//////////////////////////////////////////////////////////
	HighSpeedSetI2CStart();

	//////////////////////////////////////////////////////////
	// Send control byte and check ACK bit
	//////////////////////////////////////////////////////////
	bSucceed = SendByteAndCheckACK(devRead);
    
    // Issue stop to get SCL/SDA high
    HighSpeedSetI2CStop();

    // If the Ack did not send the trailer bytes then send them now
    ftStatus = FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);	

    //Purge USB receive buffer 
	ftStatus = FT_GetQueueStatus(ftHandle, &dwNumInputBuffer);	
	if ((ftStatus == FT_OK) && (dwNumInputBuffer > 0))
			FT_Read(ftHandle, &InputBuffer, dwNumInputBuffer, &dwNumBytesRead);  

    return(bSucceed);
}

FT_STATUS
inaRegRead( BYTE Device, BYTE Reg, USHORT *pData )
{
    BYTE devRead  = (Device<<1) |  1;
    BYTE devWrite = (Device<<1) & ~1;
    BOOL bSucceed = TRUE;
    
    BYTE Data[2];

    ftStatus         = FT_OTHER_ERROR;
    dwNumBytesToSend = 0;

	//////////////////////////////////////////////////////////
	// Set I2C start condition
	//////////////////////////////////////////////////////////
	HighSpeedSetI2CStart();

	//////////////////////////////////////////////////////////
	// Send control byte and check ACK bit
	//////////////////////////////////////////////////////////
	bSucceed = SendByteAndCheckACK(devWrite);

	//////////////////////////////////////////////////////////
	// Send high address byte and check ACK bit
	//////////////////////////////////////////////////////////
    if(bSucceed) {
        bSucceed = SendByteAndCheckACK(Reg);
    }

	//////////////////////////////////////////////////////////
	// Set I2C start condition
	//////////////////////////////////////////////////////////
	if(bSucceed) {
        HighSpeedSetI2CStart();	 
    }

	//////////////////////////////////////////////////////////
	// Send control byte and check ACK bit again
	//////////////////////////////////////////////////////////
    if(bSucceed) {
        bSucceed = SendByteAndCheckACK(devRead);
    }

    if(bSucceed) {

        // BIT     NAME
        //  0       SK (SCL)
        //  1       Dout
        //  2       Din
        //
        // Format: 0x80 Value, Dir 1=Out, 0-In
        // 
	    //////////////////////////////////////////////////////////
	    // Read the data from 24LC02B with no ACK bit check
	    //////////////////////////////////////////////////////////
	    //dwNumBytesToSend = 0;			//Clear output buffer
        Data[0] = Data[1] = 0;
        for( int i=0; i<2; i++){
	        OutputBuffer[dwNumBytesToSend++] = '\x80'; 	// Set pins
	        OutputBuffer[dwNumBytesToSend++] = '\x00'; 	// SCL-0, SDA-0
	        OutputBuffer[dwNumBytesToSend++] = '\x01';	// SCL-OUT, SDA-IN
	        OutputBuffer[dwNumBytesToSend++] = MSB_FALLING_EDGE_CLOCK_BYTE_IN; 	//Command to clock data byte in on �Cve Clock Edge MSB first
	        OutputBuffer[dwNumBytesToSend++] = '\x00';
	        OutputBuffer[dwNumBytesToSend++] = '\x00';	//Data length of 0x0000 means 1 byte data to clock in
    	 
            // SDA out for ack
    	    OutputBuffer[dwNumBytesToSend++] = '\x80'; 	// Set pins
	        OutputBuffer[dwNumBytesToSend++] = '\x00'; 	// SCL-0, SDA-0
	        OutputBuffer[dwNumBytesToSend++] = '\x03';	// SCL-OUT, SDA-OUT

            // Send ACK
	        OutputBuffer[dwNumBytesToSend++] = 0x33; 	//Command to scan in acknowledge bit , -ve clock Edge MSB first
	        OutputBuffer[dwNumBytesToSend++] = '\x0';	//Length of 0 means to scan in 1 bit
	        OutputBuffer[dwNumBytesToSend++] = '\x0';	//data 0

	        OutputBuffer[dwNumBytesToSend++] = '\x87';	//Send answer back immediate command
	        ftStatus = FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);		//Send off the commands
	        dwNumBytesToSend = 0;			//Clear output buffer
	        ftStatus |= FT_Read(ftHandle, InputBuffer, 2, &dwNumBytesRead);//Read one byte from device receive buffer, may need try more times
            Data[i] = InputBuffer[0];		//return the data read from EEPROM
            if( FT_OK != ftStatus ){
                break;
            }
        }
	    OutputBuffer[dwNumBytesToSend++] = '\x80'; 	//Command to set directions of lower 8 pins and force value on bits set as output
	    OutputBuffer[dwNumBytesToSend++] = '\x02'; 	//Set SDA high, SCL low, WP disabled by SK at bit '0', DO, GPIOL0 at bit '1'
	    OutputBuffer[dwNumBytesToSend++] = '\x03';	//Set SK,DO,GPIOL0 pins as output with bit ��1��, other pins as input with bit ��0��

	    //////////////////////////////////////////////////////////
	    // Set I2C stop condition and tristate the pins
	    //////////////////////////////////////////////////////////
	    HighSpeedSetI2CStop();

	    //Send off the commands
	    ftStatus |= FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);

        *pData = (USHORT)Data[0]<< 8 | (USHORT)Data[1];    
    }
    return (ftStatus);

}

FT_STATUS
inaRegWrite( BYTE Device, BYTE Reg, USHORT Data )
{
    BYTE devRead  = (Device<<1) |  1;
    BYTE devWrite = (Device<<1) & ~1;
    BOOL bSucceed = TRUE;

    ftStatus = FT_OTHER_ERROR;
    dwNumBytesToSend = 0;

	//////////////////////////////////////////////////////////
	// Set I2C start condition
	//////////////////////////////////////////////////////////
	HighSpeedSetI2CStart();

	//////////////////////////////////////////////////////////
	// Send control byte and check ACK bit
	//////////////////////////////////////////////////////////
	bSucceed = SendByteAndCheckACK(devWrite);

	//////////////////////////////////////////////////////////
	// Send high address byte and check ACK bit
	//////////////////////////////////////////////////////////
    if(bSucceed) {
        bSucceed = SendByteAndCheckACK(Reg);
    }

	//////////////////////////////////////////////////////////
	// Send control byte and check ACK bit again
	//////////////////////////////////////////////////////////
    if(bSucceed) {
        bSucceed = SendByteAndCheckACK((BYTE)(Data>>8));
    }

    //////////////////////////////////////////////////////////
	// Send control byte and check ACK bit again
	//////////////////////////////////////////////////////////
    if(bSucceed) {
        bSucceed = SendByteAndCheckACK((BYTE)(Data));
    }

    ////////////////////////////////////////////////////////////////////////
	// Set I2C Stop Condition
	////////////////////////////////////////////////////////////////////////
	HighSpeedSetI2CStop();


	if(bSucceed) {
        ftStatus = FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
	    dwNumBytesToSend = 0;			//Clear output buffer
    }
  
    return (ftStatus);

}

FT_STATUS
inaInit( BYTE Device, USHORT Data )
{

    FT_STATUS status;
    ftStatus = FT_OTHER_ERROR;
    dwNumBytesToSend = 0;

    status = inaRegWrite( Device,  INA_REG_CONFIG, Data );
    if( FT_OK == status ){
        USHORT RetData;
        Sleep(1);
        status = inaRegRead( Device, INA_REG_CONFIG, &RetData );
        if(  Verbose >= MSG_DEBUG ){
            printf("   Device 0x%02x, Reg %d, value: 0x%04x\n",  Device, INA_REG_CONFIG, RetData);
        }
    } else {
       if(  Verbose >= MSG_DEBUG ){
           printf("   Device 0x%02x, Reg %d, FT_STATUS %d\n",  Device, INA_REG_CONFIG, status);
       }
    }

    return status;

}

void inaCreate(  INA_DEV *pDev,
                 BYTE Address, 
                 const char *Name, 
                 double MonResistor,
                 double VbusExpectedMv,
                 double VbusDeltaMv)
{
    memset(pDev,0, sizeof(INA_DEV));
    pDev->Address        = Address;
    pDev->Device         = Name;
    pDev->MonResistor    = MonResistor;
    pDev->VbusExpectedMv = VbusExpectedMv;
    pDev->VbusDeltaMv    = VbusDeltaMv;

}

FT_STATUS
inaUpdate(){

    int status = FT_OK;

    for( int dev=0; dev<sizeof(DevList)/sizeof(INA_DEV); dev++ ){
        if( DevList[dev].Present ){
            USHORT Shunt,Bus;
            status = inaRegRead( DevList[dev].Address, INA_REG_SHUNT, &Shunt );
            if( FT_OK == status ){
                DevList[dev].regShunt = Shunt;
            }

            status = inaRegRead( DevList[dev].Address, INA_REG_BUS,   &Bus   );
            if( FT_OK == status ){
                DevList[dev].regBus = Bus;
            } 
        }
    }
    return( status );
}
/*F***************************************************************************
* NAME:  ParseArgcArgv()  
*
* DESCRIPTION: Parse command line arguments
*
* NOTES:
*   
*F***************************************************************************/
int
ParseArgcArgv( int argc, _TCHAR* argv[] )
{

    int i; 
    int Abort = 0;
    int ArgCount = 0;

    /*-----------------------------------------------------------------------*/
    /* PROCESS COMMAND LINE ARGUMENTS                                        */
    /*-----------------------------------------------------------------------*/
    for (i = 1; i < argc; ++i)
    {
        _TCHAR* argp = argv[i];
        if (*argp == '-')                      /* OPTIONS                     */
        {
            Abort = 0;
            ArgCount++;

            while (!Abort && *++argp)
            {
                switch(*argp)
                {
              
                    case 'P': case 'p':
                        if ( *++argp == '\0' )
                        {
                            if( ++i < argc )
                                argp = argv[i];
                            else
                                break;
                        }
                        swscanf(argp, L"%d" , &ConfigPort);
                        Abort = 1;
                        break;

                    case 'C': case 'c':
                        if ( *++argp == '\0' )
                        {
                            if( ++i < argc )
                                argp = argv[i];
                            else
                                break;
                        }
                        swscanf(argp, L"%x" , &ConfigVal);
                        Abort = 1;
                        break;

          
                    case 'D': case 'd':
                        if ( *++argp == '\0' )
                        {
                            if( ++i < argc )
                                argp = argv[i];
                            else
                                break;
                        }
                        swscanf(argp, L"%d" , &ConfigDelay);
                        Abort = 1;
                        break;

                    case 'M': case 'm':
                        if ( *++argp == '\0' )
                        {
                            if( ++i < argc )
                                argp = argv[i];
                            else
                                break;
                        }
                        swscanf(argp, L"%x" , &ConfigMask);
                        Abort = 1;
                        break;
                    
                    case 'N': case 'n':
                        if ( *++argp == '\0' )
                        {
                            if( ++i < argc )
                                argp = argv[i];
                            else
                                break;
                        }
                        swscanf(argp, L"%d" , &ConfigNumSamples);
                        Abort = 1;
                        break;

                    case 'V': case 'v':
                        if ( *++argp == '\0' )
                        {
                            if( ++i < argc )
                                argp = argv[i];
                            else
                                break;
                        }
                        swscanf(argp, L"%d" , &Verbose);
                        Abort = 1;
                        break;
                      default :
                         continue;
                 }  /*End of switch */
            }  /* End of while */
        } /* End of if */

        /* If Abort == 2 then stop processing and execute current command */
        if( Abort == 2 )
            break;
    }/* End of for */

    if( 0 == ArgCount ){
        printf("*** Operational Parameters ***\n");
        printf("    -p  : %d\n", ConfigPort);
        printf("    -c  : 0x%2x\n",ConfigVal );
        printf("    -d  : %d\n", ConfigDelay);
        printf("    -m  : 0x%02x\n", ConfigMask);
        printf("    -n  : %d\n", ConfigNumSamples);
        printf("    -v  : %d\n", Verbose);
    } else {
        if(  Verbose >= MSG_DEBUG ){
            printf("*** Operational Parameters ***\n");
            printf("    -p  : %d\n", ConfigPort);
            printf("    -c  : 0x%2x\n",ConfigVal );
            printf("    -d  : %d\n", ConfigDelay);
            printf("    -m  : 0x%02x\n", ConfigMask);
            printf("    -n  : %d\n", ConfigNumSamples);
            printf("    -v  : %d\n", Verbose);
        }
    }

    return( ArgCount );
}

int FTDI_Find_SDI2C( DWORD * pDevIndex )
{
	//////////////////////////////////////////////////////////
	/// INITIALIZE SECTION
	///////////////////////////////

	//////////////////////////////////////////////////////////////////
	// Define the variables used 
	//////////////////////////////////////////////////////////////////
	
	DWORD devIndex = 0;
    ftHandle = NULL;
	char Buf[64];


    for( devIndex=0; devIndex<10; devIndex++){
        ftStatus = FT_OK;
        memset(Buf,0,sizeof(Buf));

	    ftStatus = FT_ListDevices((PVOID)devIndex,&Buf, FT_LIST_BY_INDEX|FT_OPEN_BY_SERIAL_NUMBER);

        // Opened devices will return an opened error so skip
        switch( ftStatus )
        {
            case FT_OK:
            case FT_DEVICE_NOT_FOUND:
                break;

            case FT_DEVICE_NOT_OPENED:
                continue;
                break;

            default :
		    return 1;
	    }

        ftStatus = FT_INVALID_HANDLE;

        // Simple test for SD prefix.
        if( (    ( 'S' == Buf[0] ) 
              && ( 'D' == Buf[1] ) 
              && ( 'I' == Buf[2] )
              && ( '2' == Buf[3] )
              && ( 'C' == Buf[4] ) )){
            if(  Verbose >= MSG_DEBUG ){
               printf("Found Spectrum Digital device at index %d\n", devIndex);
            }
            if( NULL != pDevIndex){
                *pDevIndex = devIndex;
                return FT_OK;
            }
        }
    }
    return 1;
}


int InitFTDI()
{
	//////////////////////////////////////////////////////////
	/// INITIALIZE SECTION
	///////////////////////////////

	//////////////////////////////////////////////////////////////////
	// Define the variables used 
	//////////////////////////////////////////////////////////////////
	
	DWORD dwCount;
	DWORD devIndex = ConfigPort;
    ftHandle = NULL;
	char Buf[64];

    ftStatus = FT_OK;
    memset(Buf,0,sizeof(Buf));

	ftStatus = FT_ListDevices((PVOID)devIndex,&Buf, FT_LIST_BY_INDEX|FT_OPEN_BY_SERIAL_NUMBER);

	if (ftStatus != FT_OK)
	{
		printf("Can't open FT2232H device! \n");
		getchar();
		return 1;
	}


    ftStatus = FT_INVALID_HANDLE;

    // Simple test for SD prefix.
    if( (    ( 'S' == Buf[0] ) 
          && ( 'D' == Buf[1] ) 
          && ( 'I' == Buf[2] )
          && ( '2' == Buf[3] )
          && ( 'C' == Buf[4] ) )){
        if(  Verbose >= MSG_DEBUG ){
           printf("Found Spectrum Digital device\n");
        }
	    ftStatus = FT_OpenEx((PVOID)Buf, FT_OPEN_BY_SERIAL_NUMBER, &ftHandle);
    } else {
#if defined( SUPPORT_NON_SDI2C )
        if(  Verbose >= MSG_DEBUG ){
            printf("Found FTDI generic device\n");
        }
	    ftStatus = FT_OpenEx((PVOID)Buf, FT_OPEN_BY_SERIAL_NUMBER, &ftHandle);
#else 
        return(2);
#endif
    }

	if(ftStatus == FT_OK )
    {      // Port opened successfully
		if(  Verbose >= MSG_DEBUG ){
            printf("Successfully open FT2232H device! \n");
        }

		ftStatus |= FT_ResetDevice(ftHandle); 	//Reset USB device
		//Purge USB receive buffer first by reading out all old data from FT2232H receive buffer
		ftStatus |= FT_GetQueueStatus(ftHandle, &dwNumInputBuffer);	 // Get the number of bytes in the FT2232H receive buffer
		if ((ftStatus == FT_OK) && (dwNumInputBuffer > 0))
				FT_Read(ftHandle, &InputBuffer, dwNumInputBuffer, &dwNumBytesRead);  	//Read out the data from FT2232H receive buffer
		ftStatus |= FT_SetUSBParameters(ftHandle, 65536, 65535);	//Set USB request transfer size
		ftStatus |= FT_SetChars(ftHandle, false, 0, false, 0);	 //Disable event and error characters
		ftStatus |= FT_SetTimeouts(ftHandle, 0, 5000);		//Sets the read and write timeouts in milliseconds for the FT2232H
		ftStatus |= FT_SetLatencyTimer(ftHandle, 16);		//Set the latency timer
		ftStatus |= FT_SetBitMode(ftHandle, 0x0, 0x00); 		//Reset controller
		ftStatus |= FT_SetBitMode(ftHandle, 0x0, 0x02);	 	//Enable MPSSE mode

		if (ftStatus != FT_OK)
		{
			printf("fail on initialize FT2232H device! \n");
			getchar();
			return 1;
		}
		Sleep(50);	// Wait for all the USB stuff to complete and work

		//////////////////////////////////////////////////////////////////
		// Synchronize the MPSSE interface by sending bad command ��0xAA��
		//////////////////////////////////////////////////////////////////
		OutputBuffer[dwNumBytesToSend++] = '\xAA';		//Add BAD command ��0xAA��
		ftStatus = FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);	// Send off the BAD commands
		dwNumBytesToSend = 0;			//Clear output buffer
		do{
			ftStatus = FT_GetQueueStatus(ftHandle, &dwNumInputBuffer);	 // Get the number of bytes in the device input buffer
		}while ((dwNumInputBuffer == 0) && (ftStatus == FT_OK));   	//or Timeout
		
		bool bCommandEchod = false;
		ftStatus = FT_Read(ftHandle, &InputBuffer, dwNumInputBuffer, &dwNumBytesRead);  //Read out the data from input buffer
		for (dwCount = 0; dwCount < dwNumBytesRead - 1; dwCount++)	//Check if Bad command and echo command received
		{
			if ((InputBuffer[dwCount] == BYTE('\xFA')) && (InputBuffer[dwCount+1] == BYTE('\xAA')))
			{
				bCommandEchod = true;
				break;
			}
		}
		if (bCommandEchod == false) 
		{	
			printf("fail to synchronize MPSSE with command '0xAA' \n");
			getchar();
			return 1; /*Error, can��t receive echo command , fail to synchronize MPSSE interface;*/ 
		}
		
		//////////////////////////////////////////////////////////////////
		// Synchronize the MPSSE interface by sending bad command ��0xAB��
		//////////////////////////////////////////////////////////////////
		//dwNumBytesToSend = 0;			//Clear output buffer
		OutputBuffer[dwNumBytesToSend++] = '\xAB';	//Send BAD command ��0xAB��
		ftStatus = FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);	// Send off the BAD commands
		dwNumBytesToSend = 0;			//Clear output buffer
		do{
			ftStatus = FT_GetQueueStatus(ftHandle, &dwNumInputBuffer);	//Get the number of bytes in the device input buffer
		}while ((dwNumInputBuffer == 0) && (ftStatus == FT_OK));   //or Timeout
		bCommandEchod = false;
		ftStatus = FT_Read(ftHandle, &InputBuffer, dwNumInputBuffer, &dwNumBytesRead);  //Read out the data from input buffer
		for (dwCount = 0;dwCount < dwNumBytesRead - 1; dwCount++)	//Check if Bad command and echo command received
		{
			if ((InputBuffer[dwCount] == BYTE('\xFA')) && (InputBuffer[dwCount+1] == BYTE( '\xAB')))
			{
				bCommandEchod = true;
				break;
			}
		}
		if (bCommandEchod == false)  
		{	
			printf("fail to synchronize MPSSE with command '0xAB' \n");
			getchar();
			return 1; 
			/*Error, can��t receive echo command , fail to synchronize MPSSE interface;*/ 
		}

		//printf("MPSSE synchronized with BAD command \n");

		////////////////////////////////////////////////////////////////////
		//Configure the MPSSE for I2C communication with 24LC02B
		//////////////////////////////////////////////////////////////////
		OutputBuffer[dwNumBytesToSend++] = '\x8A'; 	//Ensure disable clock divide by 5 for 60Mhz master clock
		OutputBuffer[dwNumBytesToSend++] = '\x97';	 //Ensure turn off adaptive clocking
		OutputBuffer[dwNumBytesToSend++] = '\x8D'; 	//Enable 3 phase data clock, used by I2C to allow data on both clock edges
		ftStatus = FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);	// Send off the commands
		dwNumBytesToSend = 0;			//Clear output buffer
		OutputBuffer[dwNumBytesToSend++] = '\x80'; 	//Command to set directions of lower 8 pins and force value on bits set as output 
		OutputBuffer[dwNumBytesToSend++] = '\x03'; 	//Set SDA, SCL high, WP disabled by SK, DO at bit ��1��, GPIOL0 at bit ��0��
		OutputBuffer[dwNumBytesToSend++] = '\x13';	//Set SK,DO,GPIOL0 pins as output with bit ��1��, other pins as input with bit ��0��
		// The SK clock frequency can be worked out by below algorithm with divide by 5 set as off
		// SK frequency  = 60MHz /((1 +  [(1 +0xValueH*256) OR 0xValueL])*2)
		OutputBuffer[dwNumBytesToSend++] = '\x86'; 			//Command to set clock divisor
		OutputBuffer[dwNumBytesToSend++] = dwClockDivisor & '\xFF';	//Set 0xValueL of clock divisor
		OutputBuffer[dwNumBytesToSend++] = (dwClockDivisor >> 8) & '\xFF';	//Set 0xValueH of clock divisor
		ftStatus = FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);	// Send off the commands
		dwNumBytesToSend = 0;			//Clear output buffer
		Sleep(20);		//Delay for a while

		//Turn off loop back in case
		OutputBuffer[dwNumBytesToSend++] = '\x85';		//Command to turn off loop back of TDI/TDO connection
		ftStatus = FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);	// Send off the commands
		dwNumBytesToSend = 0;			//Clear output buffer
		Sleep(30);		//Delay for a while
	}
    if(ftStatus == FT_OK ){
        Sleep(100);
	    //Purge USB receive buffer first before read operation
	    ftStatus = FT_GetQueueStatus(ftHandle, &dwNumInputBuffer);	 // Get the number of bytes in the device receive buffer
	    if ((ftStatus == FT_OK) && (dwNumInputBuffer > 0))
			    FT_Read(ftHandle, &InputBuffer, dwNumInputBuffer, &dwNumBytesRead);  //Read out all the data from receive buffer
    }

    return( ftStatus );
}

int _tmain(int argc, _TCHAR* argv[])
{
	BOOL bSucceed = TRUE;
    USHORT Data   = 0;
    DWORD Update  = 1; 
    DWORD sdi2cDevIndex = -1;

    ftHandle = NULL;

    ParseArgcArgv( argc, argv );
    
    if( FT_OK == FTDI_Find_SDI2C( &sdi2cDevIndex )) {

        // sdi2cDevIndex should always be the first instance
        // of the SDI2C which is an even port number.  So 
        // we can add in the user requested offset of 0 or 1.
        //
        ConfigPort += sdi2cDevIndex;

    if( FT_OK != InitFTDI()){
        if( NULL != ftHandle ){
            FT_Close(ftHandle);
            
        }
        exit(-1);
    }
    } else {
        exit(-1);
    }


#if defined( VAYU_CPU )
    inaCreate( &DevList[0], I2C_ADDR_VDD_DSPEVE,   "VDD_DSPEVE  ", 0.001,1050,(1050*.05)); 
    inaCreate( &DevList[1], I2C_ADDR_VDD_MPU,      "VDD_MPU     ", 0.001,1090,(1090*.05)); 
    inaCreate( &DevList[2], I2C_ADDR_DDR_CPU,      "DDR_CPU     ", 0.005,1350,(1350*.05)); 
    inaCreate( &DevList[3], I2C_ADDR_VDDA_1V8_PLL, "VDDA_1V8_PLL", 0.010,1800,(1800*.05));
    inaCreate( &DevList[4], I2C_ADDR_VDD_GPU,      "VDD_GPU     ", 0.002,1050,(1050*.05));
    inaCreate( &DevList[5], I2C_ADDR_VUSB_3V3,     "VUSB_3V3    ", 0.010,3300,(3300*.05));
    inaCreate( &DevList[6], I2C_ADDR_VDDS18V,      "VDDS18V     ", 0.010,1800,(1800*.05));
    inaCreate( &DevList[7], I2C_ADDR_VDD_SHV,      "VDD_SHV     ", 0.001,3300,(3300*.05));
    inaCreate( &DevList[8], I2C_ADDR_CORE_VDD,     "CORE_VDD    ", 0.002,1020,(1020*.05));
    inaCreate( &DevList[9], I2C_ADDR_VDD_IVA,      "VDD_IVA     ", 0.002,1050,(1050*.05));
    inaCreate( &DevList[10],I2C_ADDR_DDR_MEM,      "DDR_MEM     ", 0.005,1350,(1350*.05));
    inaCreate( &DevList[11],I2C_ADDR_VDDA_1V8_PHY, "VDDA_1V8_PHY", 0.010,1800,(1800*.05));
#elif defined( DM8148_CPU )
    inaCreate( &DevList[0], I2C_ADDR_VDD_DSPEVE,   "VDD_DSPEVE  ", 0.001,1050,(1050*.05)); 
    inaCreate( &DevList[1], I2C_ADDR_VDD_MPU,      "VDD_MPU     ", 0.001,1220,(1220*.05)); 
    inaCreate( &DevList[2], I2C_ADDR_DDR_CPU,      "DDR_CPU     ", 0.005,1350,(1350*.05)); 
    inaCreate( &DevList[3], I2C_ADDR_VDDA_1V8_PLL, "VDDA_1V8_PLL", 0.010,1800,(1800*.05));
    inaCreate( &DevList[4], I2C_ADDR_VDD_GPU,      "VDD_GPU     ", 0.002,1050,(1050*.05));
    inaCreate( &DevList[5], I2C_ADDR_VUSB_3V3,     "VUSB_3V3    ", 0.010,3300,(3300*.05));
    inaCreate( &DevList[6], I2C_ADDR_VDDS18V,      "VDDS18V     ", 0.010,1800,(1800*.05));
    inaCreate( &DevList[7], I2C_ADDR_VDD_SHV,      "VDD_SHV     ", 0.001,3300,(3300*.05));
    inaCreate( &DevList[8], I2C_ADDR_CORE_VDD,     "CORE_VDD    ", 0.002,1020,(1020*.05));
    inaCreate( &DevList[9], I2C_ADDR_VDD_IVA,      "VDD_IVA     ", 0.002,1050,(1050*.05));
    inaCreate( &DevList[10],I2C_ADDR_DDR_MEM,      "DDR_MEM     ", 0.005,1350,(1350*.05));
    inaCreate( &DevList[11],I2C_ADDR_VDDA_1V8_PHY, "VDDA_1V8_PHY", 0.010,1800,(1800*.05));
#else
	// Create a full table of INA devices    
    inaCreate( &DevList[0], I2C_ADDR_U73, "U73", 0.010,0,(0*.05)); 
    inaCreate( &DevList[1], I2C_ADDR_U75, "U75", 0.010,0,(0*.05)); 
    inaCreate( &DevList[2], I2C_ADDR_U78, "U78", 0.010,0,(0*.05)); 
    inaCreate( &DevList[3], I2C_ADDR_U80, "U80", 0.010,0,(0*.05));
    inaCreate( &DevList[4], I2C_ADDR_U74, "U74", 0.010,0,(0*.05));
    inaCreate( &DevList[5], I2C_ADDR_U81, "U81", 0.010,0,(0*.05));
    inaCreate( &DevList[6], I2C_ADDR_U82, "U82", 0.010,0,(0*.05));
    inaCreate( &DevList[7], I2C_ADDR_U83, "U83", 0.010,0,(0*.05));
    inaCreate( &DevList[8], I2C_ADDR_U76, "U76", 0.010,0,(0*.05));
    inaCreate( &DevList[9], I2C_ADDR_U77, "U77", 0.010,0,(0*.05));
    inaCreate( &DevList[10],I2C_ADDR_U79, "U79", 0.010,0,(0*.05));
    inaCreate( &DevList[11],I2C_ADDR_U84, "U84", 0.010,0,(0*.05));
#endif

    // Try to find INA device if not masked off
    for(int dev=0; dev<sizeof(DevList)/sizeof(INA_DEV); dev++){
        if( ConfigMask & 1 ){
            DevList[dev].Present = inaPresent( DevList[dev].Address);   
            if( DevList[dev].Present ){
                if(  Verbose >= MSG_DEBUG ){
                    printf("Dev at 0x%02x, %s\n", DevList[dev].Address,DevList[dev].Device);
                }
            } else {
                if(  Verbose >= MSG_DEBUG ){
                    printf("No Dev at 0x%02x, %s\n", DevList[dev].Address,DevList[dev].Device);
                }
            }
        } else {
            if(  Verbose >= MSG_DEBUG ){
                printf("Skipping Dev at 0x%02x\n", DevList[dev].Address);
            }
        }
        ConfigMask = ConfigMask>>1;
    }

    // Configure the INA devices
    Sleep(100);
    for(int dev=0; dev<sizeof(DevList)/sizeof(INA_DEV); dev++){
        if( DevList[dev].Present ){
            inaInit( DevList[dev].Address, (USHORT)ConfigVal );
        }
    }

    // Dump the registers of the enabled INA devices
    for(int dev=0; dev<sizeof(DevList)/sizeof(INA_DEV); dev++){
        if( DevList[dev].Present ){
             if(  Verbose >= MSG_DEBUG ){
                 printf("Dev 0x%02x\n", DevList[dev].Address);
             }
             for(int i=0; i<6; i++){
                Data = 0;
                inaRegRead( DevList[dev].Address, (BYTE)i, &Data );
                if(  Verbose >= MSG_DEBUG ){ 
                    printf("   Reg %d:, value: 0x%04x\n", i, Data);
                }
            }
        }
    }

    Update = ConfigNumSamples;

    while( Update-- ){
        FT_STATUS supd;
        supd = inaUpdate();
        if( FT_OK == supd ){
            for( int dev=0; dev<sizeof(DevList)/sizeof(INA_DEV); dev++ ){
                if( DevList[dev].Present ){
                    // (int)(short) - sign extends
                    double Shunt = (double)((int)(short)DevList[dev].regShunt); 
                    double Bus   = (double)((int)DevList[dev].regBus);
                    double LowRange  = DevList[dev].VbusExpectedMv-DevList[dev].VbusDeltaMv;
                    double HighRange = DevList[dev].VbusExpectedMv+DevList[dev].VbusDeltaMv;

                    Shunt = Shunt * SHUNT_UV_PER_LSB; 
                    Bus   = Bus   * BUS_MV_PER_LSB;
                    DevList[dev].VbusSumMv += Bus;

                    double Current = ( Shunt / DevList[dev].MonResistor)/1000;
                    if(  Verbose >= MSG_MEASURE ){
                        printf("Measure %s, Bus = %4.2fmV, Shunt = %5.4fuV, Current = %3.4fmA\n", DevList[dev].Device, Bus, Shunt,Current);
                    }
                }
            }
                if(  Verbose >= MSG_MEASURE ){
                    printf("\n");
                }
            }
        if( ConfigDelay > 0 ){
            Sleep(ConfigDelay);
        }
    }

    if(  Verbose == MSG_RANGE ){
        for( int dev=0; dev<sizeof(DevList)/sizeof(INA_DEV); dev++ ){

            if( DevList[dev].Present ){
                double Bus       = DevList[dev].VbusSumMv/ConfigNumSamples;
                double LowRange  = DevList[dev].VbusExpectedMv-DevList[dev].VbusDeltaMv;
                double HighRange = DevList[dev].VbusExpectedMv+DevList[dev].VbusDeltaMv;
                if( DevList[dev].VbusExpectedMv > 0 ){
                    if(   ( Bus < LowRange )
                        ||( Bus > HighRange )){
                            bSucceed = FALSE;
                            printf("ERROR - %s, Average  %4.2fmV : Expected Range %4.2fmV -  %4.2fmV\n",  DevList[dev].Device,Bus, LowRange, HighRange);
                    }
                }
            }
        }
    }
    
    if( FALSE ==  bSucceed ){
        printf("FAILED FAILED FAILED\n");
    } else {
        printf("PASSED PASSED PASSED\n");
    }

	dwNumBytesToSend = 0;			//Clear output buffer
    FT_Close(ftHandle);

    return bSucceed ? -1 : 0;
}

